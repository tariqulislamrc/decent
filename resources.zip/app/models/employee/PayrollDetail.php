<?php

namespace App\models\employee;

use Illuminate\Database\Eloquent\Model;

class PayrollDetail extends Model
{
    //
}
