<?php

namespace App\models\eCommerce;

use Illuminate\Database\Eloquent\Model;

class OurWorkspace extends Model
{
    protected $guarded  = [];
}
