<?php

namespace App\Models\Production;

use Illuminate\Database\Eloquent\Model;

class ProductVariationTemplate extends Model
{
    //
}
