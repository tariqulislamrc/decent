<?php

namespace App\models\employee;

use Illuminate\Database\Eloquent\Model;

class LeaveAllocationDetail extends Model
{
    //
}
