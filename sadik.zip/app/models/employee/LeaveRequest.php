<?php

namespace App\models\employee;

use Illuminate\Database\Eloquent\Model;

class LeaveRequest extends Model
{
    //
}
