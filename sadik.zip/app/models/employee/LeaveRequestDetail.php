<?php

namespace App\models\employee;

use Illuminate\Database\Eloquent\Model;

class LeaveRequestDetail extends Model
{
    //
}
