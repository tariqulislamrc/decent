<?php

namespace App\models\eCommerce;

use Illuminate\Database\Eloquent\Model;

class Coupon extends Model
{
    protected $guarded  = [];
}
