<?php

namespace App\models\eCommerce;

use Illuminate\Database\Eloquent\Model;

class AboutUs extends Model{
    protected $guarded  = [];
}
