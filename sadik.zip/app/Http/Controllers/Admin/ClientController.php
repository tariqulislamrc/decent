<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\models\Client;
use App\models\Production\Transaction;
use App\models\Production\TransactionPayment;
use App\models\email\EmailTemolate;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Yajra\DataTables\Facades\DataTables;

class ClientController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('admin.client.index');
    }

    public function datatable(Request $request){
       if ($request->ajax()) {
            $document = Client::all();
            return DataTables::of($document)
                ->addIndexColumn()
                ->addColumn('action', function ($model) {
                    return view('admin.client.action', compact('model'));
                })->rawColumns(['action'])->make(true);
        }
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.client.form');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $validator = $request->validate([
            'name'=>'required',
            'mobile'=>'required',
            'email'=>'nullable|email',
            'net_total'=>'nullable|numeric',
        ]);

         $input = $request->only(['type',
                'name', 'mobile', 'landline', 'alternate_number', 'city', 'state', 'country', 'landmark', 'email']);
         $input['created_by'] = auth()->user()->id;
         $contact = Client::create($input);

        $ym = Carbon::now()->format('Y/m');

        $row = Transaction::where('transaction_type', 'opening_balance')->withTrashed()->get()->count() > 0 ? Transaction::where('transaction_type', 'opening_balance')->withTrashed()->get()->count() + 1 : 1;
        
        $ref_no = $ym.'/Open-'.ref($row);
        $transaction = Transaction::create([
        'client_id'=>$contact->id,
        'date'=>Carbon::now(),
        'type'=>'Debit',
        'reference_no'=>$ref_no,
        'transaction_type'=>'opening_balance',
        'net_total'=>$request->net_total,
        'created_by'=>auth()->user()->id,
        ]);

     return response()->json(['success' => true, 'status' => 'success', 'message' => _lang('Information Created')]);
    }

    public function quick_add(Request $request)
    {
        $validator = $request->validate([
            'name'=>'required',
            'mobile'=>'required',
            'email'=>'nullable|email',
            'net_total'=>'nullable|numeric',
        ]);

         $input = $request->only(['type',
                'name', 'mobile', 'landline', 'alternate_number', 'city', 'state', 'country', 'landmark', 'email']);
         $input['created_by'] = auth()->user()->id;
         $contact = Client::create($input);
         return response()->json(['id'=>$contact->id,'name'=>$contact->name,'addto'=>'customer_id','modal'=>'contact_modal']);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
           $model =Client::find($id);
            $ob_transaction =  Transaction::where('client_id', $id)
                                            ->where('transaction_type', 'opening_balance')
                                            ->first();                          
            $opening_balance = !empty($ob_transaction->net_total) ? $ob_transaction->net_total : 0;

            //Deduct paid amount from opening balance.
            if (!empty($opening_balance)) {
                $opening_balance_paid = $this->getTotalAmountPaid($ob_transaction->id);
                if (!empty($opening_balance_paid)) {
                    $opening_balance = $opening_balance - $opening_balance_paid;
                }

            }
       return view('admin.client.form',compact('model','opening_balance'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $request->validate([
            'name'=>'required',
            'mobile'=>'required',
            'email'=>'nullable|email',
            'net_total'=>'nullable|numeric',
        ]);

         $input = $request->only(['type',
                'name', 'mobile', 'landline', 'alternate_number', 'city', 'state', 'country', 'landmark', 'email']);
         $input['updated_by'] = auth()->user()->id;
         $contact =Client::find($id);
         $contact->update($input);

        $ob_transaction =  Transaction::where('client_id', $id)
                                        ->where('transaction_type', 'opening_balance')
                                        ->first();  

      if (!empty($ob_transaction)) {
                $amount =$request->input('net_total');
                $opening_balance_paid = $this->getTotalAmountPaid($ob_transaction->id);
                if (!empty($opening_balance_paid)) {
                    $amount += $opening_balance_paid;
                }
                
                $ob_transaction->net_total = $amount;
                $ob_transaction->save();
                //Update opening balance payment status
                // $this->transactionUtil->updatePaymentStatus($ob_transaction->id, $ob_transaction->net_total);
            } else {
                //Add opening balance
                if (!empty($request->input('net_total'))) {
                     $ym = Carbon::now()->format('Y/m');

                        $row = Transaction::where('transaction_type', 'opening_balance')->withTrashed()->get()->count() > 0 ? Transaction::where('transaction_type', 'opening_balance')->withTrashed()->get()->count() + 1 : 1;
                        
                        $ref_no = $ym.'/Open-'.ref($row);
                        $transaction = Transaction::create([
                        'client_id'=>$contact->id,
                        'date'=>Carbon::now(),
                        'type'=>'Debit',
                        'reference_no'=>$ref_no,
                        'transaction_type'=>'opening_balance',
                        'net_total'=>$request->net_total,
                        'created_by'=>auth()->user()->id,
                        ]);
                }
            }

         
     return response()->json(['success' => true, 'status' => 'success', 'message' => _lang('Information Updated')]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
     $count = Transaction::where('client_id', $id)
                         ->count();
    if ($count == 0) {                  
       $model= Client::find($id);
        $model->delete();
        if ($model) {
            return response()->json(['success' => true, 'status' => 'success', 'message' => 'Information Delete Successfully.']);
        }
    }
    else{
      throw ValidationException::withMessages(['message' => _lang('You Cannot Delete this Contact')]);
    }

    }

    public function email($id)
    {
        $model =Client::find($id);
        $templates = EmailTemolate::pluck('name','id');
        return view('admin.client.mail',compact('model','templates'));
    }

    public function sms($id)
    {
        $model =Client::find($id);
        return view('admin.client.sms',compact('model'));
    }


    private function getTotalAmountPaid($transaction_id)
    {
        $paid = TransactionPayment::where(
            'transaction_id',
            $transaction_id
        )->sum('amount');
        return $paid;
    }

   public function customers()
    {
        if (request()->ajax()) {
            $term = request()->input('q', '');

            $contacts = Client::query();

            if (!empty($term)) {
                $contacts->where(function ($query) use ($term) {
                    $query->where('name', 'like', '%' . $term .'%')
                            ->orWhere('mobile', 'like', '%' . $term .'%');
                });
            }

            $contacts = $contacts->select(
                'id',
                'name as text',
                'mobile',
                'landmark',
                'city',
                'state'
            )
                    ->get();

            return json_encode($contacts);
        }
    }
}



