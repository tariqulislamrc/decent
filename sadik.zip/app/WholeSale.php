<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WholeSale extends Model
{
    protected $guarded = [];
}
