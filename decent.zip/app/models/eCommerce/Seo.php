<?php

namespace App\models\eCommerce;

use Illuminate\Database\Eloquent\Model;

class Seo extends Model
{
    protected $guarded  = [];
}
