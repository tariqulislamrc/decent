<?php

namespace App\models\eCommerce;

use Illuminate\Database\Eloquent\Model;

class ProductRating extends Model
{
     protected $guarded  = [];
}
