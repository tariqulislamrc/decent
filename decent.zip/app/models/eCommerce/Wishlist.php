<?php

namespace App\models\eCommerce;

use Illuminate\Database\Eloquent\Model;

class Wishlist extends Model
{
    //
}
