<?php

namespace App\models\eCommerce;

use Illuminate\Database\Eloquent\Model;

class OurTeam extends Model{
    protected $guarded  = [];
}
