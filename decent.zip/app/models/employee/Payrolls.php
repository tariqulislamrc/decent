<?php

namespace App\models\employee;

use Illuminate\Database\Eloquent\Model;

class Payrolls extends Model
{
    //
}
