<?php

namespace App\models\employee;

use Illuminate\Database\Eloquent\Model;

class IdGenerator extends Model
{
    protected $guarded = ['id'];
}
