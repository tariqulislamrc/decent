<?php

namespace App\models\employee;

use Illuminate\Database\Eloquent\Model;

class EmployeeQualification extends Model
{
    //
}
