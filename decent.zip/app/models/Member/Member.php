<?php

namespace App\models\Member;

use Illuminate\Database\Eloquent\Model;

class Member extends Model
{
    //
}
