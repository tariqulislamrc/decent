<?php

namespace App\models\email;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class EmailMedia extends Model
{
      use SoftDeletes;
}
