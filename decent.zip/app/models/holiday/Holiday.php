<?php

namespace App\models\holiday;

use Illuminate\Database\Eloquent\Model;

class Holiday extends Model
{
    //
}
