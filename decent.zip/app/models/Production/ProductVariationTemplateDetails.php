<?php

namespace App\Models\Production;

use Illuminate\Database\Eloquent\Model;

class ProductVariationTemplateDetails extends Model
{
    //
}
