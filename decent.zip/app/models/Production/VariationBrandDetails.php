<?php

namespace App\models\Production;

use Illuminate\Database\Eloquent\Model;

class VariationBrandDetails extends Model
{
    //
}
