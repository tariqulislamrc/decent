<?php

namespace App\models\Production;

use Illuminate\Database\Eloquent\Model;

class VariationTemplateDetails extends Model
{
    //
}
