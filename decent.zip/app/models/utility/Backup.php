<?php

namespace App\models\utility;

use Illuminate\Database\Eloquent\Model;

class Backup extends Model
{
    //
}
