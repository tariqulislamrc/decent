<?php

namespace App\models\utility;

use Illuminate\Database\Eloquent\Model;

class Upload extends Model
{
    //
}
