@can('email_marketing.view')
    <button class="btn btn-info btn-sm has-tooltip" data-original-title="null" id="content_managment" data-url="{{route('admin.emailmarketing.email_history_view',$model->id)}}" > <i class="fa fa-eye-slash" aria-hidden="true"></i></button>
@endcan


